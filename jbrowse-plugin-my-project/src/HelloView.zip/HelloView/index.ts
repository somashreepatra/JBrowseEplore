export { default as ReactComponent } from './components/HelloView'
export { default as stateModel } from './stateModel'
